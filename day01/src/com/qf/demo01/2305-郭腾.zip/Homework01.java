package com.qf.demo01;
/**
 * 郭腾的简历
 * @author XC
 *
 */
public class Homework01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "郭腾";
		int age = 22;
		//性别（0：女，1：男)
		int gender = 1;
		//学历
		String edu_bg = "本科";
		//专业
		String major = "软件工程";
		//身份证
		String id = "41100220010116103X";
		//电话号
		String phonenum = "+8617838375446";
		double height = 1.8;
		int weight = 80;
		String title = "学生";
		System.out.println("姓名\t年龄\t性别\t学历\t专业\t身份证号\t\t\t电话号\t\t身高(米)\t体重（公斤)\t职称");
		System.out.println(name + "\t" + age + "\t" + gender + "\t" + edu_bg + "\t" + major + "\t" + id + "\t" + phonenum + "\t" + height + "\t" + weight + "\t" +title);
	}

}
